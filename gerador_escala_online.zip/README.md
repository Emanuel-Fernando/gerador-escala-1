# Gerador de Escala Online (Flask + React)

Este pacote contém **backend (Flask)** e **frontend (React)** prontos para deploy:

- Backend: Render.com (Python/WSGI com Gunicorn)
- Frontend: Vercel (build React)

## Passo a passo (resumo)
1) Publique `/backend` no Render.com
   - Build: `pip install -r requirements.txt`
   - Start: `gunicorn app:app`
   - Porta: 5000 (Render detecta automaticamente)
   - Copie a URL gerada (ex: https://gerador-escala-api.onrender.com)

2) No `/frontend/src/api.js`, ajuste `baseURL` para a URL do backend acima.

3) Publique `/frontend` na Vercel
   - Build: `npm run build`
   - Output: `build`

4) Teste acessando a URL da Vercel (site público).

## Dicas
- CORS já está habilitado no Flask.
- No plano grátis do Render, a primeira chamada pode demorar alguns segundos ao “acordar” a instância.